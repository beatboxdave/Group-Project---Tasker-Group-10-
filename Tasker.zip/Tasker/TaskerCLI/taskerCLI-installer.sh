#!/bin/bash

echo "---------------TaskerCLI installer-----------------"
echo "Please enter in the destination location:"
read destination

unzip ./taskerCLI.zip -d $destination




