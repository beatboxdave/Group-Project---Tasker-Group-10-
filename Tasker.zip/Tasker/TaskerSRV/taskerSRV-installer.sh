#!/bin/bash

echo "---------------TaskerSRV installer--------------------"

mysql -h db.dcs.aber.ac.uk -u csgpadm_10 -d csgp_10_15_16 -p



