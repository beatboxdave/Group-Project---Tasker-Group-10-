<?php
	$servername = "db.dcs.aber.ac.uk";
	$username = "csgpadm_10";
	$password = "W1C74Fjh";
	$dbname = "csgp_10_15_16";
?>